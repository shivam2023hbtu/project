import { Box } from "@chakra-ui/react";
import React from "react";
import { Curosel } from "../Components/Navbar/Curosel";
const Home = () => {
  return (
    <Box bg={"#eef6f9"}>
      <Curosel/>
    </Box>
  );
};

export default Home;
