export const data = [
    {
        "search": "Mobile",
    },
    {
        "search": "Shirt",
    },
    {
        "search": "T-Shirt",
    },
    {
        "search": "Jacket",
    },
    {
        "search": "Accessories",
    },
    {
        "search": "Shoes",
    },
    {
        "search": "Trousers",
    },
    {
        "search": "Sunglasses",
    },
    {
        "search": "TV",
    },
    {
        "search": "Refrigerators",
    },
    {
        "search": "Heater",
    },
    {
        "search": "Inverter",
    },
    {
        "search": "Laptop",
    },
    {
        "search": "Headphone",
    },
    {
        "search": "Mouse",
    },
    {
        "search": "Printer",
    },
    {
        "search": "Keyboard",
    }
]