
# E Commerce App

Home page of an ecommerce using reactjs.



## Project Screenshots
### Home Page
![Image1](https://i.postimg.cc/gkB4xFhN/i1.png)

### Dropdown
![Image2](https://i.postimg.cc/x8fgz9gF/i2.png)

### Searchbar
![Image3](https://i.postimg.cc/4N3B4NYY/i3.png)
